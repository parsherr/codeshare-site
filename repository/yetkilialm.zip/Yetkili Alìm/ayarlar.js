module.exports = {
    token: '', 
    sahipID: '',
  };