module.exports = {
    soru1: 'Günde kaç saat aktif olursun?',
    soru2: 'Daha önce hiç yetkili oldun mu?',
    soru3: 'Daha önce hangi projelerde çalıştın?',
    soru4: 'Mikrofonun var mı?',
    soru5: 'Bu sunucuya neler katacaksın?',
  };